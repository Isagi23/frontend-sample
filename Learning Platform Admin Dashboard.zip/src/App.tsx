import { useState } from 'react';
import { AdminDashboard } from './components/AdminDashboard';
import { TeacherDashboard } from './components/TeacherDashboard';
import { StudentDashboard } from './components/StudentDashboard';
import { Button } from './components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { GraduationCap } from 'lucide-react';
import { Toaster } from './components/ui/sonner';

type UserRole = 'admin' | 'teacher' | 'student' | null;

export default function App() {
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [currentUser, setCurrentUser] = useState<any>(null);

  const handleLogin = (role: UserRole) => {
    setUserRole(role);
    // Mock user data
    if (role === 'admin') {
      setCurrentUser({ id: '1', name: 'Admin User', email: 'admin@school.edu' });
    } else if (role === 'teacher') {
      setCurrentUser({ id: '2', name: 'Prof. Johnson', email: 'johnson@school.edu' });
    } else if (role === 'student') {
      setCurrentUser({ id: '3', name: 'Alex Smith', email: 'alex@student.edu' });
    }
  };

  const handleLogout = () => {
    setUserRole(null);
    setCurrentUser(null);
  };

  if (!userRole) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div className="bg-indigo-600 p-4 rounded-full">
                <GraduationCap className="w-12 h-12 text-white" />
              </div>
            </div>
            <CardTitle>Learning Platform</CardTitle>
            <CardDescription>Select your role to continue</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button 
              onClick={() => handleLogin('admin')} 
              className="w-full"
              variant="default"
            >
              Login as Admin
            </Button>
            <Button 
              onClick={() => handleLogin('teacher')} 
              className="w-full"
              variant="default"
            >
              Login as Teacher
            </Button>
            <Button 
              onClick={() => handleLogin('student')} 
              className="w-full"
              variant="default"
            >
              Login as Student
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {userRole === 'admin' && <AdminDashboard user={currentUser} onLogout={handleLogout} />}
      {userRole === 'teacher' && <TeacherDashboard user={currentUser} onLogout={handleLogout} />}
      {userRole === 'student' && <StudentDashboard user={currentUser} onLogout={handleLogout} />}
      <Toaster />
    </div>
  );
}