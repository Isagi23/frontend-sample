import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Sparkles, Send, Bot, User, BookOpen, Brain, HelpCircle, Lightbulb } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export function AIAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hi! I'm your AI Study Assistant. I can help you with homework, explain concepts, suggest study strategies, and answer questions about your courses. How can I help you today?",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const quickPrompts = [
    { icon: BookOpen, text: "Explain this topic", query: "Can you explain " },
    { icon: Brain, text: "Study tips", query: "Give me study tips for " },
    { icon: HelpCircle, text: "Solve problem", query: "Help me solve this problem: " },
    { icon: Lightbulb, text: "Summarize", query: "Summarize the key points of " }
  ];

  useEffect(() => {
    // Scroll to bottom when new messages arrive
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const simulateAIResponse = (userMessage: string): string => {
    // Simple keyword-based responses for demonstration
    const lowerMessage = userMessage.toLowerCase();
    
    if (lowerMessage.includes('quiz') || lowerMessage.includes('test')) {
      return "To prepare for your quiz, I recommend:\n\n1. Review your class notes and highlight key concepts\n2. Practice with sample questions\n3. Create flashcards for important terms\n4. Take breaks every 25-30 minutes (Pomodoro technique)\n5. Get enough sleep before the test\n\nWould you like me to help you with any specific topic from your course?";
    }
    
    if (lowerMessage.includes('data structure') || lowerMessage.includes('algorithm')) {
      return "Data structures and algorithms are fundamental to computer science! Here's a quick overview:\n\n**Common Data Structures:**\n- Arrays: Fixed-size collections\n- Linked Lists: Dynamic collections with nodes\n- Stacks: Last-In-First-Out (LIFO)\n- Queues: First-In-First-Out (FIFO)\n- Trees: Hierarchical structures\n- Hash Tables: Key-value pairs\n\n**Algorithm Complexity:**\nWe measure efficiency using Big O notation (O(n), O(log n), etc.)\n\nWhat specific topic would you like to dive deeper into?";
    }
    
    if (lowerMessage.includes('python') || lowerMessage.includes('programming')) {
      return "Python is a great language for beginners! Here are some tips:\n\n**Python Basics:**\n- Variables don't need type declarations\n- Indentation is crucial (use 4 spaces)\n- Lists are like arrays: `my_list = [1, 2, 3]`\n- Functions: `def my_function():`\n- Loops: `for item in list:` or `while condition:`\n\n**Best Practices:**\n- Use meaningful variable names\n- Comment your code\n- Follow PEP 8 style guide\n\nWhat aspect of Python programming would you like help with?";
    }
    
    if (lowerMessage.includes('study') || lowerMessage.includes('learn')) {
      return "Here are proven study techniques that work great for students:\n\n**Active Learning:**\n- Teach concepts to someone else (Feynman Technique)\n- Create mind maps and diagrams\n- Practice with real problems\n\n**Time Management:**\n- Use the Pomodoro Technique (25 min focus + 5 min break)\n- Study most difficult subjects when you're most alert\n- Review material within 24 hours of learning it\n\n**Memory Techniques:**\n- Spaced repetition\n- Create mnemonics\n- Connect new info to what you already know\n\nWould you like specific tips for any of your courses?";
    }

    if (lowerMessage.includes('assignment') || lowerMessage.includes('homework')) {
      return "I can help you with your assignments! Here's my approach:\n\n1. **Understand the Requirements:** Read the instructions carefully\n2. **Break It Down:** Divide the assignment into smaller tasks\n3. **Research:** Gather relevant information and resources\n4. **Outline:** Plan your approach before diving in\n5. **Review:** Check your work before submitting\n\nWhat assignment are you working on? Share the details and I'll provide more specific guidance!";
    }
    
    // Default response
    return "I'm here to help you succeed in your studies! I can assist with:\n\n✨ Explaining difficult concepts\n📚 Homework and assignment guidance\n🧠 Study strategies and tips\n💡 Problem-solving techniques\n📊 Exam preparation\n\nFeel free to ask me anything about your courses, or use the quick prompts above to get started!";
  };

  const handleSendMessage = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages([...messages, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response with delay
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: simulateAIResponse(input),
        timestamp: new Date()
      };

      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const handleQuickPrompt = (query: string) => {
    setInput(query);
  };

  return (
    <div className="space-y-6">
      {/* AI Features Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center space-x-2">
              <BookOpen className="w-5 h-5 text-blue-600" />
              <CardTitle>Study Help</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-500">Get explanations for difficult topics</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center space-x-2">
              <Brain className="w-5 h-5 text-purple-600" />
              <CardTitle>Smart Tips</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-500">Personalized study strategies</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center space-x-2">
              <HelpCircle className="w-5 h-5 text-green-600" />
              <CardTitle>Problem Solving</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-500">Step-by-step guidance</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-orange-600" />
              <CardTitle>24/7 Available</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-gray-500">Always ready to help</p>
          </CardContent>
        </Card>
      </div>

      {/* Chat Interface */}
      <Card className="h-[600px] flex flex-col">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-6 h-6 text-purple-600" />
              <div>
                <CardTitle>AI Study Assistant</CardTitle>
                <CardDescription>Powered by AI to help you learn better</CardDescription>
              </div>
            </div>
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              <div className="w-2 h-2 bg-green-600 rounded-full mr-2" />
              Online
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col p-0">
          {/* Quick Prompts */}
          <div className="px-6 py-3 border-b bg-gray-50">
            <div className="flex flex-wrap gap-2">
              {quickPrompts.map((prompt, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuickPrompt(prompt.query)}
                  className="text-sm"
                >
                  <prompt.icon className="w-3 h-3 mr-1" />
                  {prompt.text}
                </Button>
              ))}
            </div>
          </div>

          {/* Messages */}
          <ScrollArea className="flex-1 px-6">
            <div className="space-y-4 py-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex ${message.role === 'user' ? 'flex-row-reverse' : 'flex-row'} items-start space-x-2 max-w-[80%]`}>
                    <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                      message.role === 'user' ? 'bg-indigo-600 ml-2' : 'bg-purple-600 mr-2'
                    }`}>
                      {message.role === 'user' ? (
                        <User className="w-5 h-5 text-white" />
                      ) : (
                        <Bot className="w-5 h-5 text-white" />
                      )}
                    </div>
                    <div
                      className={`rounded-lg px-4 py-2 ${
                        message.role === 'user'
                          ? 'bg-indigo-600 text-white'
                          : 'bg-gray-100 text-gray-900'
                      }`}
                    >
                      <p className="whitespace-pre-wrap">{message.content}</p>
                      <p className={`text-xs mt-1 ${
                        message.role === 'user' ? 'text-indigo-200' : 'text-gray-500'
                      }`}>
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex justify-start">
                  <div className="flex items-start space-x-2">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center mr-2">
                      <Bot className="w-5 h-5 text-white" />
                    </div>
                    <div className="bg-gray-100 rounded-lg px-4 py-3">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          {/* Input Area */}
          <div className="px-6 py-4 border-t bg-white">
            <div className="flex space-x-2">
              <Input
                placeholder="Ask me anything about your studies..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                disabled={isTyping}
              />
              <Button onClick={handleSendMessage} disabled={isTyping || !input.trim()}>
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              💡 Tip: The AI assistant uses mock responses. Connect to an AI API for real-time assistance.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}