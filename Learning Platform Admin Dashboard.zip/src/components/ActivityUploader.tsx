import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Plus, Upload, Calendar, FileText } from 'lucide-react';

export function ActivityUploader() {
  const [activities, setActivities] = useState([
    { 
      id: '1', 
      title: 'Assignment 1: Variables and Data Types', 
      class: 'Introduction to Computer Science', 
      dueDate: '2025-10-25', 
      submissions: 18,
      totalStudents: 25,
      points: 100
    },
    { 
      id: '2', 
      title: 'Lab: Arrays and Linked Lists', 
      class: 'Data Structures', 
      dueDate: '2025-10-22', 
      submissions: 25,
      totalStudents: 30,
      points: 50
    },
  ]);

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newActivity, setNewActivity] = useState({
    title: '',
    description: '',
    class: '',
    dueDate: '',
    points: '',
    file: null as File | null
  });

  const handleAddActivity = () => {
    if (newActivity.title && newActivity.class && newActivity.dueDate) {
      setActivities([
        ...activities,
        {
          id: String(activities.length + 1),
          title: newActivity.title,
          class: newActivity.class,
          dueDate: newActivity.dueDate,
          submissions: 0,
          totalStudents: 25,
          points: parseInt(newActivity.points) || 100
        }
      ]);
      setNewActivity({ title: '', description: '', class: '', dueDate: '', points: '', file: null });
      setIsAddDialogOpen(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Activities & Assignments</CardTitle>
            <CardDescription>Create and manage class activities</CardDescription>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Create Activity
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Activity</DialogTitle>
                <DialogDescription>Upload a new assignment or activity for your class</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="activityTitle">Activity Title</Label>
                  <Input
                    id="activityTitle"
                    placeholder="e.g., Assignment 1: Introduction to Python"
                    value={newActivity.title}
                    onChange={(e) => setNewActivity({ ...newActivity, title: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="activityDescription">Description</Label>
                  <Textarea
                    id="activityDescription"
                    placeholder="Describe the activity and what students need to do..."
                    value={newActivity.description}
                    onChange={(e) => setNewActivity({ ...newActivity, description: e.target.value })}
                    rows={4}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="activityClass">Class</Label>
                    <Select value={newActivity.class} onValueChange={(value) => setNewActivity({ ...newActivity, class: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a class" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Introduction to Computer Science">Introduction to Computer Science</SelectItem>
                        <SelectItem value="Data Structures">Data Structures</SelectItem>
                        <SelectItem value="Web Development">Web Development</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dueDate">Due Date</Label>
                    <Input
                      id="dueDate"
                      type="date"
                      value={newActivity.dueDate}
                      onChange={(e) => setNewActivity({ ...newActivity, dueDate: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="points">Points</Label>
                  <Input
                    id="points"
                    type="number"
                    placeholder="100"
                    value={newActivity.points}
                    onChange={(e) => setNewActivity({ ...newActivity, points: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="file">Attach Files (Optional)</Label>
                  <div className="border-2 border-dashed rounded-lg p-8 text-center hover:border-gray-400 transition-colors">
                    <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-gray-500">Click to upload or drag and drop</p>
                    <p className="text-gray-400">PDF, DOC, DOCX up to 10MB</p>
                    <Input
                      id="file"
                      type="file"
                      className="hidden"
                      onChange={(e) => setNewActivity({ ...newActivity, file: e.target.files?.[0] || null })}
                    />
                  </div>
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddActivity}>Create Activity</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Activity</TableHead>
              <TableHead>Class</TableHead>
              <TableHead>Due Date</TableHead>
              <TableHead>Submissions</TableHead>
              <TableHead>Points</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {activities.map((activity) => (
              <TableRow key={activity.id}>
                <TableCell>
                  <div className="flex items-center">
                    <FileText className="w-4 h-4 mr-2 text-gray-400" />
                    <span>{activity.title}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{activity.class}</Badge>
                </TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                    {activity.dueDate}
                  </div>
                </TableCell>
                <TableCell>
                  {activity.submissions}/{activity.totalStudents}
                </TableCell>
                <TableCell>{activity.points}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" size="sm">View</Button>
                    <Button variant="outline" size="sm">Edit</Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
