import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Badge } from './ui/badge';
import { LogOut, Users, BookOpen, BarChart3, UserPlus, School } from 'lucide-react';
import { StudentManager } from './StudentManager';
import { TeacherManager } from './TeacherManager';
import { ClassManager } from './ClassManager';
import { EnrollmentManager } from './EnrollmentManager';
import { Reports } from './Reports';

interface AdminDashboardProps {
  user: any;
  onLogout: () => void;
}

export function AdminDashboard({ user, onLogout }: AdminDashboardProps) {
  const [stats] = useState({
    totalStudents: 245,
    totalTeachers: 18,
    totalClasses: 32,
    activeQuizzes: 12
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <School className="w-8 h-8 text-indigo-600" />
              <div>
                <h1 className="text-gray-900">Learning Platform Admin</h1>
                <p className="text-gray-500">System Administration</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-gray-900">{user.name}</p>
                <Badge variant="secondary">Admin</Badge>
              </div>
              <Avatar>
                <AvatarFallback>AD</AvatarFallback>
              </Avatar>
              <Button onClick={onLogout} variant="outline" size="sm">
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle>Total Students</CardTitle>
              <Users className="w-4 h-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-gray-900">{stats.totalStudents}</div>
              <p className="text-gray-500">Enrolled students</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle>Total Teachers</CardTitle>
              <UserPlus className="w-4 h-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-gray-900">{stats.totalTeachers}</div>
              <p className="text-gray-500">Active instructors</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle>Total Classes</CardTitle>
              <BookOpen className="w-4 h-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-gray-900">{stats.totalClasses}</div>
              <p className="text-gray-500">Active classes</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle>Active Quizzes</CardTitle>
              <BarChart3 className="w-4 h-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-gray-900">{stats.activeQuizzes}</div>
              <p className="text-gray-500">Ongoing assessments</p>
            </CardContent>
          </Card>
        </div>

        {/* Management Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="students">Students</TabsTrigger>
            <TabsTrigger value="teachers">Teachers</TabsTrigger>
            <TabsTrigger value="classes">Classes</TabsTrigger>
            <TabsTrigger value="enrollment">Enrollment</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <Reports />
          </TabsContent>

          <TabsContent value="students">
            <StudentManager />
          </TabsContent>

          <TabsContent value="teachers">
            <TeacherManager />
          </TabsContent>

          <TabsContent value="classes">
            <ClassManager isAdmin={true} />
          </TabsContent>

          <TabsContent value="enrollment">
            <EnrollmentManager />
          </TabsContent>

          <TabsContent value="reports">
            <Reports />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
