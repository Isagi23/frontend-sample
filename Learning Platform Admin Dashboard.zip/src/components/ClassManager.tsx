import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Badge } from './ui/badge';
import { Plus, Users, BookOpen } from 'lucide-react';

interface ClassManagerProps {
  isAdmin: boolean;
}

export function ClassManager({ isAdmin }: ClassManagerProps) {
  const [classes, setClasses] = useState([
    { 
      id: '1', 
      name: 'Introduction to Computer Science', 
      description: 'Learn the fundamentals of programming and computer science',
      teacher: 'Prof. Johnson', 
      students: 25, 
      color: 'bg-blue-500' 
    },
    { 
      id: '2', 
      name: 'Data Structures', 
      description: 'Advanced data structures and algorithms',
      teacher: 'Dr. Smith', 
      students: 30, 
      color: 'bg-green-500' 
    },
    { 
      id: '3', 
      name: 'Web Development', 
      description: 'Modern web development with React and Node.js',
      teacher: 'Prof. Williams', 
      students: 28, 
      color: 'bg-purple-500' 
    },
  ]);

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newClass, setNewClass] = useState({ name: '', description: '', teacher: '' });

  const handleAddClass = () => {
    if (newClass.name && newClass.description) {
      const colors = ['bg-blue-500', 'bg-green-500', 'bg-purple-500', 'bg-red-500', 'bg-yellow-500', 'bg-indigo-500'];
      setClasses([
        ...classes,
        {
          id: String(classes.length + 1),
          name: newClass.name,
          description: newClass.description,
          teacher: newClass.teacher || 'Unassigned',
          students: 0,
          color: colors[Math.floor(Math.random() * colors.length)]
        }
      ]);
      setNewClass({ name: '', description: '', teacher: '' });
      setIsAddDialogOpen(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-gray-900">Classes</h2>
          <p className="text-gray-500">
            {isAdmin ? 'Manage all classes in the system' : 'Your teaching classes'}
          </p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Create Class
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Class</DialogTitle>
              <DialogDescription>Add a new class to the platform</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="className">Class Name</Label>
                <Input
                  id="className"
                  placeholder="e.g., Introduction to Computer Science"
                  value={newClass.name}
                  onChange={(e) => setNewClass({ ...newClass, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Brief description of the class"
                  value={newClass.description}
                  onChange={(e) => setNewClass({ ...newClass, description: e.target.value })}
                />
              </div>
              {isAdmin && (
                <div className="space-y-2">
                  <Label htmlFor="teacher">Assign Teacher</Label>
                  <Input
                    id="teacher"
                    placeholder="Teacher name"
                    value={newClass.teacher}
                    onChange={(e) => setNewClass({ ...newClass, teacher: e.target.value })}
                  />
                </div>
              )}
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddClass}>Create Class</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {classes.map((classItem) => (
          <Card key={classItem.id} className="hover:shadow-lg transition-shadow overflow-hidden">
            <div className={`${classItem.color} h-32 flex items-center justify-center`}>
              <BookOpen className="w-12 h-12 text-white" />
            </div>
            <CardHeader>
              <CardTitle>{classItem.name}</CardTitle>
              <CardDescription>{classItem.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between text-gray-500">
                  <span>Teacher:</span>
                  <Badge variant="outline">{classItem.teacher}</Badge>
                </div>
                <div className="flex items-center justify-between text-gray-500">
                  <span className="flex items-center">
                    <Users className="w-4 h-4 mr-1" />
                    Students:
                  </span>
                  <span>{classItem.students}</span>
                </div>
                <div className="flex space-x-2 pt-2">
                  <Button variant="outline" className="flex-1" size="sm">
                    View
                  </Button>
                  <Button variant="outline" className="flex-1" size="sm">
                    Edit
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
