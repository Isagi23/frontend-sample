import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Search, UserPlus, BookOpen, Users } from 'lucide-react';
import { Checkbox } from './ui/checkbox';

export function EnrollmentManager() {
  const [searchTerm, setSearchTerm] = useState('');
  const [isEnrollDialogOpen, setIsEnrollDialogOpen] = useState(false);
  const [selectedClass, setSelectedClass] = useState<any>(null);
  const [selectedStudents, setSelectedStudents] = useState<string[]>([]);

  const [classes] = useState([
    { 
      id: '1', 
      name: 'Introduction to Computer Science', 
      teacher: 'Prof. Johnson',
      enrolled: 25,
      capacity: 30,
      schedule: 'Mon, Wed, Fri 10:00 AM',
      color: 'bg-blue-500'
    },
    { 
      id: '2', 
      name: 'Data Structures', 
      teacher: 'Dr. Smith',
      enrolled: 30,
      capacity: 35,
      schedule: 'Tue, Thu 2:00 PM',
      color: 'bg-green-500'
    },
    { 
      id: '3', 
      name: 'Web Development', 
      teacher: 'Prof. Williams',
      enrolled: 28,
      capacity: 30,
      schedule: 'Mon, Wed 1:00 PM',
      color: 'bg-purple-500'
    },
  ]);

  const [students] = useState([
    { id: '1', name: 'Alex Smith', email: 'alex@student.edu', enrolledClasses: ['1'] },
    { id: '2', name: 'Emma Johnson', email: 'emma@student.edu', enrolledClasses: ['1', '2'] },
    { id: '3', name: 'Michael Brown', email: 'michael@student.edu', enrolledClasses: ['2'] },
    { id: '4', name: 'Sarah Davis', email: 'sarah@student.edu', enrolledClasses: [] },
    { id: '5', name: 'James Wilson', email: 'james@student.edu', enrolledClasses: ['3'] },
  ]);

  const handleEnrollStudents = () => {
    // In a real app, this would update the database
    setSelectedStudents([]);
    setIsEnrollDialogOpen(false);
    setSelectedClass(null);
  };

  const toggleStudentSelection = (studentId: string) => {
    setSelectedStudents(prev =>
      prev.includes(studentId)
        ? prev.filter(id => id !== studentId)
        : [...prev, studentId]
    );
  };

  const filteredClasses = classes.filter(cls =>
    cls.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cls.teacher.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Enrollment Management</CardTitle>
          <CardDescription>Manage student enrollments in classes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search classes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredClasses.map((classItem) => (
              <Card key={classItem.id} className="overflow-hidden">
                <div className={`${classItem.color} h-24 flex items-center justify-center`}>
                  <BookOpen className="w-12 h-12 text-white" />
                </div>
                <CardHeader>
                  <CardTitle>{classItem.name}</CardTitle>
                  <CardDescription>{classItem.teacher}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-gray-500">
                    <p>Schedule: {classItem.schedule}</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-gray-500">
                      <Users className="w-4 h-4 mr-1" />
                      <span>{classItem.enrolled}/{classItem.capacity}</span>
                    </div>
                    <Badge variant={classItem.enrolled < classItem.capacity ? 'default' : 'secondary'}>
                      {classItem.enrolled < classItem.capacity ? 'Open' : 'Full'}
                    </Badge>
                  </div>
                  <Dialog
                    open={isEnrollDialogOpen && selectedClass?.id === classItem.id}
                    onOpenChange={(open) => {
                      setIsEnrollDialogOpen(open);
                      if (!open) setSelectedClass(null);
                    }}
                  >
                    <DialogTrigger asChild>
                      <Button
                        className="w-full"
                        variant="outline"
                        onClick={() => setSelectedClass(classItem)}
                        disabled={classItem.enrolled >= classItem.capacity}
                      >
                        <UserPlus className="w-4 h-4 mr-2" />
                        Enroll Students
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Enroll Students</DialogTitle>
                        <DialogDescription>
                          Select students to enroll in {classItem.name}
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div className="space-y-3 max-h-96 overflow-y-auto">
                          {students
                            .filter(student => !student.enrolledClasses.includes(classItem.id))
                            .map((student) => (
                              <div
                                key={student.id}
                                className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50"
                              >
                                <div className="flex items-center space-x-3">
                                  <Checkbox
                                    checked={selectedStudents.includes(student.id)}
                                    onCheckedChange={() => toggleStudentSelection(student.id)}
                                  />
                                  <div>
                                    <p className="text-gray-900">{student.name}</p>
                                    <p className="text-gray-500">{student.email}</p>
                                  </div>
                                </div>
                                <Badge variant="outline">
                                  {student.enrolledClasses.length} classes
                                </Badge>
                              </div>
                            ))}
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <p className="text-gray-500">
                          {selectedStudents.length} student(s) selected
                        </p>
                        <div className="flex space-x-2">
                          <Button
                            variant="outline"
                            onClick={() => {
                              setIsEnrollDialogOpen(false);
                              setSelectedClass(null);
                              setSelectedStudents([]);
                            }}
                          >
                            Cancel
                          </Button>
                          <Button
                            onClick={handleEnrollStudents}
                            disabled={selectedStudents.length === 0}
                          >
                            Enroll Students
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Enrolled Students by Class */}
      <Card>
        <CardHeader>
          <CardTitle>Enrolled Students</CardTitle>
          <CardDescription>View students enrolled in each class</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {classes.map((classItem) => (
              <div key={classItem.id} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="text-gray-900">{classItem.name}</h4>
                    <p className="text-gray-500">{classItem.teacher}</p>
                  </div>
                  <Badge>{classItem.enrolled} students</Badge>
                </div>
                <div className="flex flex-wrap gap-2">
                  {students
                    .filter(student => student.enrolledClasses.includes(classItem.id))
                    .map((student) => (
                      <Badge key={student.id} variant="outline">
                        {student.name}
                      </Badge>
                    ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
