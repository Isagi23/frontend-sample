import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Search, FileText, CheckCircle, Clock, XCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';

export function GradeManagement() {
  const [selectedClass, setSelectedClass] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSubmission, setSelectedSubmission] = useState<any>(null);

  const [submissions] = useState([
    {
      id: '1',
      studentName: 'Alex Smith',
      studentId: '2021001',
      assignment: 'Assignment 1: Variables and Data Types',
      class: 'Introduction to Computer Science',
      submittedDate: '2025-10-18',
      status: 'submitted',
      grade: null,
      feedback: ''
    },
    {
      id: '2',
      studentName: 'Emma Johnson',
      studentId: '2021002',
      assignment: 'Assignment 1: Variables and Data Types',
      class: 'Introduction to Computer Science',
      submittedDate: '2025-10-19',
      status: 'graded',
      grade: 95,
      feedback: 'Excellent work! Clear understanding of concepts.'
    },
    {
      id: '3',
      studentName: 'Michael Brown',
      studentId: '2021003',
      assignment: 'Lab: Arrays and Linked Lists',
      class: 'Data Structures',
      submittedDate: '2025-10-20',
      status: 'submitted',
      grade: null,
      feedback: ''
    },
    {
      id: '4',
      studentName: 'Sarah Davis',
      studentId: '2021004',
      assignment: 'Project: Build a Portfolio Website',
      class: 'Web Development',
      submittedDate: '2025-10-17',
      status: 'graded',
      grade: 88,
      feedback: 'Good work. Consider improving responsive design.'
    },
    {
      id: '5',
      studentName: 'James Wilson',
      studentId: '2021005',
      assignment: 'Assignment 1: Variables and Data Types',
      class: 'Introduction to Computer Science',
      submittedDate: '',
      status: 'late',
      grade: null,
      feedback: ''
    }
  ]);

  const [gradeForm, setGradeForm] = useState({ grade: '', feedback: '' });

  const handleGradeSubmission = () => {
    // In a real app, this would update the database
    setSelectedSubmission(null);
    setGradeForm({ grade: '', feedback: '' });
  };

  const filteredSubmissions = submissions.filter(sub => {
    const matchesSearch = sub.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         sub.assignment.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClass = selectedClass === 'all' || sub.class === selectedClass;
    return matchesSearch && matchesClass;
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Grade Submissions</CardTitle>
        <CardDescription>Review and grade student submissions</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex space-x-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search students or assignments..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={selectedClass} onValueChange={setSelectedClass}>
            <SelectTrigger className="w-64">
              <SelectValue placeholder="Filter by class" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Classes</SelectItem>
              <SelectItem value="Introduction to Computer Science">Introduction to Computer Science</SelectItem>
              <SelectItem value="Data Structures">Data Structures</SelectItem>
              <SelectItem value="Web Development">Web Development</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-gray-500">Total Submissions</p>
                <p className="text-gray-900">{submissions.length}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-gray-500">Pending Review</p>
                <p className="text-orange-600">{submissions.filter(s => s.status === 'submitted').length}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-gray-500">Graded</p>
                <p className="text-green-600">{submissions.filter(s => s.status === 'graded').length}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-gray-500">Late Submissions</p>
                <p className="text-red-600">{submissions.filter(s => s.status === 'late').length}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Student</TableHead>
              <TableHead>Assignment</TableHead>
              <TableHead>Class</TableHead>
              <TableHead>Submitted</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Grade</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredSubmissions.map((submission) => (
              <TableRow key={submission.id}>
                <TableCell>
                  <div>
                    <p className="text-gray-900">{submission.studentName}</p>
                    <p className="text-gray-500">{submission.studentId}</p>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <FileText className="w-4 h-4 mr-2 text-gray-400" />
                    {submission.assignment}
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{submission.class}</Badge>
                </TableCell>
                <TableCell>{submission.submittedDate || '-'}</TableCell>
                <TableCell>
                  {submission.status === 'graded' && (
                    <Badge className="bg-green-100 text-green-800">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Graded
                    </Badge>
                  )}
                  {submission.status === 'submitted' && (
                    <Badge className="bg-orange-100 text-orange-800">
                      <Clock className="w-3 h-3 mr-1" />
                      Pending
                    </Badge>
                  )}
                  {submission.status === 'late' && (
                    <Badge className="bg-red-100 text-red-800">
                      <XCircle className="w-3 h-3 mr-1" />
                      Late
                    </Badge>
                  )}
                </TableCell>
                <TableCell>
                  {submission.grade !== null ? (
                    <span className="text-gray-900">{submission.grade}/100</span>
                  ) : (
                    <span className="text-gray-400">-</span>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <Dialog open={selectedSubmission?.id === submission.id} onOpenChange={(open) => !open && setSelectedSubmission(null)}>
                    <DialogTrigger asChild>
                      <Button
                        variant={submission.status === 'submitted' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setSelectedSubmission(submission)}
                      >
                        {submission.status === 'graded' ? 'Review' : 'Grade'}
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Grade Submission</DialogTitle>
                        <DialogDescription>
                          {submission.studentName} - {submission.assignment}
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div className="p-4 bg-gray-50 rounded-lg">
                          <h4 className="text-gray-900 mb-2">Submission Details</h4>
                          <div className="space-y-2 text-gray-600">
                            <p>Student: {submission.studentName} ({submission.studentId})</p>
                            <p>Class: {submission.class}</p>
                            <p>Submitted: {submission.submittedDate || 'Not submitted'}</p>
                            <p>Status: {submission.status}</p>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="grade">Grade (out of 100)</Label>
                          <Input
                            id="grade"
                            type="number"
                            min="0"
                            max="100"
                            placeholder="Enter grade"
                            value={gradeForm.grade || submission.grade || ''}
                            onChange={(e) => setGradeForm({ ...gradeForm, grade: e.target.value })}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="feedback">Feedback</Label>
                          <Textarea
                            id="feedback"
                            placeholder="Provide feedback for the student..."
                            rows={6}
                            value={gradeForm.feedback || submission.feedback}
                            onChange={(e) => setGradeForm({ ...gradeForm, feedback: e.target.value })}
                          />
                        </div>
                      </div>
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline" onClick={() => setSelectedSubmission(null)}>
                          Cancel
                        </Button>
                        <Button onClick={handleGradeSubmission}>
                          {submission.status === 'graded' ? 'Update Grade' : 'Submit Grade'}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
