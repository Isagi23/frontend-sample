import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Badge } from './ui/badge';
import { CreditCard, Wallet, DollarSign, CheckCircle2, Clock, X } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Payment {
  id: string;
  amount: number;
  description: string;
  method: 'gcash' | 'maya' | 'paypal';
  status: 'pending' | 'completed' | 'failed';
  date: string;
  transactionId?: string;
}

export function PaymentManager() {
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState<'gcash' | 'maya' | 'paypal'>('gcash');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const [payments, setPayments] = useState<Payment[]>([
    {
      id: '1',
      amount: 1500,
      description: 'Enrollment Fee - Web Development',
      method: 'gcash',
      status: 'completed',
      date: '2025-10-15',
      transactionId: 'GC-12345678'
    },
    {
      id: '2',
      amount: 500,
      description: 'Quiz Materials - Data Structures',
      method: 'maya',
      status: 'completed',
      date: '2025-10-18',
      transactionId: 'MAYA-87654321'
    },
    {
      id: '3',
      amount: 2000,
      description: 'Enrollment Fee - Introduction to Computer Science',
      method: 'paypal',
      status: 'pending',
      date: '2025-10-21',
    },
  ]);

  const [balance] = useState(3500);

  const handlePayment = () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    if (!description) {
      toast.error('Please enter a description');
      return;
    }

    setIsProcessing(true);

    // Simulate payment processing
    setTimeout(() => {
      const newPayment: Payment = {
        id: Date.now().toString(),
        amount: parseFloat(amount),
        description,
        method: selectedMethod,
        status: 'completed',
        date: new Date().toISOString().split('T')[0],
        transactionId: `${selectedMethod.toUpperCase()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`
      };

      setPayments([newPayment, ...payments]);
      setIsProcessing(false);
      setIsPaymentDialogOpen(false);
      setAmount('');
      setDescription('');
      
      toast.success(`Payment of ₱${amount} via ${selectedMethod.toUpperCase()} successful!`);
    }, 2000);
  };

  const getMethodIcon = (method: string) => {
    switch (method) {
      case 'gcash':
        return <Wallet className="w-5 h-5 text-blue-600" />;
      case 'maya':
        return <CreditCard className="w-5 h-5 text-green-600" />;
      case 'paypal':
        return <DollarSign className="w-5 h-5 text-blue-500" />;
      default:
        return <CreditCard className="w-5 h-5" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-green-500"><CheckCircle2 className="w-3 h-3 mr-1" />Completed</Badge>;
      case 'pending':
        return <Badge variant="secondary"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'failed':
        return <Badge variant="destructive"><X className="w-3 h-3 mr-1" />Failed</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Balance Card */}
      <Card>
        <CardHeader>
          <CardTitle>Account Balance</CardTitle>
          <CardDescription>Your current wallet balance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-gray-900">₱{balance.toLocaleString()}</div>
              <p className="text-gray-500">Available balance</p>
            </div>
            <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <CreditCard className="w-4 h-4 mr-2" />
                  Make Payment
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Make a Payment</DialogTitle>
                  <DialogDescription>
                    Choose your preferred payment method and enter the details
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4 py-4">
                  {/* Payment Method Selection */}
                  <div className="space-y-2">
                    <Label>Payment Method</Label>
                    <RadioGroup value={selectedMethod} onValueChange={(value: any) => setSelectedMethod(value)}>
                      <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                        <RadioGroupItem value="gcash" id="gcash" />
                        <Label htmlFor="gcash" className="flex items-center flex-1 cursor-pointer">
                          <Wallet className="w-5 h-5 text-blue-600 mr-2" />
                          <div>
                            <div className="text-gray-900">GCash</div>
                            <p className="text-gray-500">Pay via GCash mobile wallet</p>
                          </div>
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                        <RadioGroupItem value="maya" id="maya" />
                        <Label htmlFor="maya" className="flex items-center flex-1 cursor-pointer">
                          <CreditCard className="w-5 h-5 text-green-600 mr-2" />
                          <div>
                            <div className="text-gray-900">Maya</div>
                            <p className="text-gray-500">Pay via Maya digital wallet</p>
                          </div>
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-gray-50">
                        <RadioGroupItem value="paypal" id="paypal" />
                        <Label htmlFor="paypal" className="flex items-center flex-1 cursor-pointer">
                          <DollarSign className="w-5 h-5 text-blue-500 mr-2" />
                          <div>
                            <div className="text-gray-900">PayPal</div>
                            <p className="text-gray-500">Pay via PayPal account</p>
                          </div>
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  {/* Amount Input */}
                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount (₱)</Label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="0.00"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      min="0"
                      step="0.01"
                    />
                  </div>

                  {/* Description Input */}
                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Input
                      id="description"
                      placeholder="e.g., Enrollment Fee, Course Materials"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsPaymentDialogOpen(false)} disabled={isProcessing}>
                    Cancel
                  </Button>
                  <Button onClick={handlePayment} disabled={isProcessing}>
                    {isProcessing ? 'Processing...' : 'Pay Now'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>

      {/* Payment Methods */}
      <Card>
        <CardHeader>
          <CardTitle>Payment Methods</CardTitle>
          <CardDescription>Available payment options</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 border rounded-lg flex items-center space-x-3">
              <Wallet className="w-8 h-8 text-blue-600" />
              <div>
                <div className="text-gray-900">GCash</div>
                <p className="text-gray-500">Mobile Wallet</p>
              </div>
            </div>
            <div className="p-4 border rounded-lg flex items-center space-x-3">
              <CreditCard className="w-8 h-8 text-green-600" />
              <div>
                <div className="text-gray-900">Maya</div>
                <p className="text-gray-500">Digital Wallet</p>
              </div>
            </div>
            <div className="p-4 border rounded-lg flex items-center space-x-3">
              <DollarSign className="w-8 h-8 text-blue-500" />
              <div>
                <div className="text-gray-900">PayPal</div>
                <p className="text-gray-500">Online Payment</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Payment History */}
      <Card>
        <CardHeader>
          <CardTitle>Payment History</CardTitle>
          <CardDescription>Your recent transactions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {payments.map((payment) => (
              <div key={payment.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-3 flex-1">
                  {getMethodIcon(payment.method)}
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <h3 className="text-gray-900">{payment.description}</h3>
                      {getStatusBadge(payment.status)}
                    </div>
                    <p className="text-gray-500">{payment.date}</p>
                    {payment.transactionId && (
                      <p className="text-gray-500">Transaction ID: {payment.transactionId}</p>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-gray-900">₱{payment.amount.toLocaleString()}</div>
                  <p className="text-gray-500">{payment.method.toUpperCase()}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
