import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Plus, FileQuestion, Clock, Trash2, CheckCircle } from 'lucide-react';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';

interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
}

export function QuizBuilder() {
  const [quizzes, setQuizzes] = useState([
    { 
      id: '1', 
      title: 'Quiz 1: Python Basics', 
      class: 'Introduction to Computer Science', 
      dueDate: '2025-10-23',
      duration: 30,
      questions: 10,
      attempts: 18,
      totalStudents: 25
    },
    { 
      id: '2', 
      title: 'Quiz 2: Tree Traversal', 
      class: 'Data Structures', 
      dueDate: '2025-10-24',
      duration: 45,
      questions: 15,
      attempts: 22,
      totalStudents: 30
    },
  ]);

  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isQuestionDialogOpen, setIsQuestionDialogOpen] = useState(false);
  const [newQuiz, setNewQuiz] = useState({
    title: '',
    class: '',
    dueDate: '',
    duration: '',
    description: ''
  });

  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState({
    question: '',
    options: ['', '', '', ''],
    correctAnswer: 0
  });

  const handleAddQuestion = () => {
    if (currentQuestion.question && currentQuestion.options.every(opt => opt.trim())) {
      setQuestions([
        ...questions,
        {
          id: String(questions.length + 1),
          question: currentQuestion.question,
          options: currentQuestion.options,
          correctAnswer: currentQuestion.correctAnswer
        }
      ]);
      setCurrentQuestion({
        question: '',
        options: ['', '', '', ''],
        correctAnswer: 0
      });
      setIsQuestionDialogOpen(false);
    }
  };

  const handleCreateQuiz = () => {
    if (newQuiz.title && newQuiz.class && newQuiz.dueDate && questions.length > 0) {
      setQuizzes([
        ...quizzes,
        {
          id: String(quizzes.length + 1),
          title: newQuiz.title,
          class: newQuiz.class,
          dueDate: newQuiz.dueDate,
          duration: parseInt(newQuiz.duration) || 30,
          questions: questions.length,
          attempts: 0,
          totalStudents: 25
        }
      ]);
      setNewQuiz({ title: '', class: '', dueDate: '', duration: '', description: '' });
      setQuestions([]);
      setIsCreateDialogOpen(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Quiz Management</CardTitle>
            <CardDescription>Create and manage quizzes for your classes</CardDescription>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Create Quiz
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create New Quiz</DialogTitle>
                <DialogDescription>Build a quiz with multiple choice questions</DialogDescription>
              </DialogHeader>
              <div className="space-y-6 py-4">
                {/* Quiz Settings */}
                <div className="space-y-4">
                  <h3 className="text-gray-900">Quiz Settings</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="quizTitle">Quiz Title</Label>
                      <Input
                        id="quizTitle"
                        placeholder="e.g., Quiz 1: Python Basics"
                        value={newQuiz.title}
                        onChange={(e) => setNewQuiz({ ...newQuiz, title: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="quizClass">Class</Label>
                      <Select value={newQuiz.class} onValueChange={(value) => setNewQuiz({ ...newQuiz, class: value })}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a class" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Introduction to Computer Science">Introduction to Computer Science</SelectItem>
                          <SelectItem value="Data Structures">Data Structures</SelectItem>
                          <SelectItem value="Web Development">Web Development</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="quizDueDate">Due Date</Label>
                      <Input
                        id="quizDueDate"
                        type="date"
                        value={newQuiz.dueDate}
                        onChange={(e) => setNewQuiz({ ...newQuiz, dueDate: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="duration">Duration (minutes)</Label>
                      <Input
                        id="duration"
                        type="number"
                        placeholder="30"
                        value={newQuiz.duration}
                        onChange={(e) => setNewQuiz({ ...newQuiz, duration: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="quizDescription">Description</Label>
                    <Textarea
                      id="quizDescription"
                      placeholder="Quiz instructions and description..."
                      value={newQuiz.description}
                      onChange={(e) => setNewQuiz({ ...newQuiz, description: e.target.value })}
                    />
                  </div>
                </div>

                {/* Questions List */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-gray-900">Questions ({questions.length})</h3>
                    <Dialog open={isQuestionDialogOpen} onOpenChange={setIsQuestionDialogOpen}>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <Plus className="w-4 h-4 mr-2" />
                          Add Question
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Add Question</DialogTitle>
                          <DialogDescription>Create a multiple choice question</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label htmlFor="questionText">Question</Label>
                            <Textarea
                              id="questionText"
                              placeholder="Enter your question..."
                              value={currentQuestion.question}
                              onChange={(e) => setCurrentQuestion({ ...currentQuestion, question: e.target.value })}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Options</Label>
                            <RadioGroup value={String(currentQuestion.correctAnswer)} onValueChange={(value) => setCurrentQuestion({ ...currentQuestion, correctAnswer: parseInt(value) })}>
                              {currentQuestion.options.map((option, index) => (
                                <div key={index} className="flex items-center space-x-2">
                                  <RadioGroupItem value={String(index)} id={`option-${index}`} />
                                  <Input
                                    placeholder={`Option ${index + 1}`}
                                    value={option}
                                    onChange={(e) => {
                                      const newOptions = [...currentQuestion.options];
                                      newOptions[index] = e.target.value;
                                      setCurrentQuestion({ ...currentQuestion, options: newOptions });
                                    }}
                                    className="flex-1"
                                  />
                                  <Label htmlFor={`option-${index}`} className="text-gray-500">
                                    {currentQuestion.correctAnswer === index && <CheckCircle className="w-4 h-4 text-green-600" />}
                                  </Label>
                                </div>
                              ))}
                            </RadioGroup>
                            <p className="text-gray-500">Select the correct answer by clicking the radio button</p>
                          </div>
                        </div>
                        <div className="flex justify-end space-x-2">
                          <Button variant="outline" onClick={() => setIsQuestionDialogOpen(false)}>
                            Cancel
                          </Button>
                          <Button onClick={handleAddQuestion}>Add Question</Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                  
                  {questions.length === 0 ? (
                    <div className="text-center py-8 border-2 border-dashed rounded-lg">
                      <FileQuestion className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-500">No questions added yet</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {questions.map((q, index) => (
                        <div key={q.id} className="p-4 border rounded-lg">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <p className="text-gray-900 mb-2">{index + 1}. {q.question}</p>
                              <div className="space-y-1">
                                {q.options.map((opt, optIndex) => (
                                  <div key={optIndex} className="flex items-center space-x-2 text-gray-600">
                                    <span className={optIndex === q.correctAnswer ? 'text-green-600' : ''}>
                                      {String.fromCharCode(65 + optIndex)}. {opt}
                                    </span>
                                    {optIndex === q.correctAnswer && (
                                      <CheckCircle className="w-4 h-4 text-green-600" />
                                    )}
                                  </div>
                                ))}
                              </div>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setQuestions(questions.filter(qu => qu.id !== q.id))}
                            >
                              <Trash2 className="w-4 h-4 text-red-600" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateQuiz} disabled={questions.length === 0}>
                  Create Quiz
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Quiz</TableHead>
              <TableHead>Class</TableHead>
              <TableHead>Due Date</TableHead>
              <TableHead>Duration</TableHead>
              <TableHead>Questions</TableHead>
              <TableHead>Attempts</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {quizzes.map((quiz) => (
              <TableRow key={quiz.id}>
                <TableCell>
                  <div className="flex items-center">
                    <FileQuestion className="w-4 h-4 mr-2 text-gray-400" />
                    <span>{quiz.title}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{quiz.class}</Badge>
                </TableCell>
                <TableCell>{quiz.dueDate}</TableCell>
                <TableCell>
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 mr-2 text-gray-400" />
                    {quiz.duration} min
                  </div>
                </TableCell>
                <TableCell>{quiz.questions}</TableCell>
                <TableCell>{quiz.attempts}/{quiz.totalStudents}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" size="sm">View Results</Button>
                    <Button variant="outline" size="sm">Edit</Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
