import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';

interface QuizTakerProps {
  quiz: any;
  onExit: () => void;
}

export function QuizTaker({ quiz, onExit }: QuizTakerProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<{ [key: number]: number }>({});
  const [timeRemaining, setTimeRemaining] = useState(quiz.duration * 60);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState(0);

  // Mock questions
  const questions = [
    {
      id: 1,
      question: 'What is the correct syntax to output "Hello World" in Python?',
      options: [
        'echo "Hello World"',
        'print("Hello World")',
        'printf("Hello World")',
        'System.out.println("Hello World")'
      ],
      correctAnswer: 1
    },
    {
      id: 2,
      question: 'Which data type is used to create a variable that should store text?',
      options: [
        'int',
        'string',
        'float',
        'boolean'
      ],
      correctAnswer: 1
    },
    {
      id: 3,
      question: 'What is the output of: print(2 ** 3)?',
      options: [
        '5',
        '6',
        '8',
        '9'
      ],
      correctAnswer: 2
    },
    {
      id: 4,
      question: 'Which keyword is used to create a function in Python?',
      options: [
        'function',
        'def',
        'func',
        'create'
      ],
      correctAnswer: 1
    },
    {
      id: 5,
      question: 'What does the len() function do?',
      options: [
        'Returns the length of an object',
        'Converts to integer',
        'Rounds a number',
        'Creates a list'
      ],
      correctAnswer: 0
    },
    {
      id: 6,
      question: 'How do you start a comment in Python?',
      options: [
        '//',
        '/* */',
        '#',
        '--'
      ],
      correctAnswer: 2
    },
    {
      id: 7,
      question: 'Which operator is used for exponentiation in Python?',
      options: [
        '^',
        '**',
        'exp()',
        'pow()'
      ],
      correctAnswer: 1
    },
    {
      id: 8,
      question: 'What is the correct file extension for Python files?',
      options: [
        '.pt',
        '.pyt',
        '.py',
        '.python'
      ],
      correctAnswer: 2
    },
    {
      id: 9,
      question: 'Which method can be used to remove whitespace from the beginning and end of a string?',
      options: [
        'trim()',
        'strip()',
        'remove()',
        'clean()'
      ],
      correctAnswer: 1
    },
    {
      id: 10,
      question: 'What will be the output of: print(type([]))?',
      options: [
        '<class \'dict\'>',
        '<class \'tuple\'>',
        '<class \'list\'>',
        '<class \'set\'>'
      ],
      correctAnswer: 2
    }
  ];

  useEffect(() => {
    if (isSubmitted) return;

    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isSubmitted]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleAnswerChange = (answerIndex: number) => {
    setAnswers({
      ...answers,
      [currentQuestionIndex]: answerIndex
    });
  };

  const handleSubmit = () => {
    let correctCount = 0;
    questions.forEach((q, index) => {
      if (answers[index] === q.correctAnswer) {
        correctCount++;
      }
    });
    setScore(Math.round((correctCount / questions.length) * 100));
    setIsSubmitted(true);
  };

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="max-w-2xl w-full">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              {score >= 70 ? (
                <div className="bg-green-100 p-6 rounded-full">
                  <CheckCircle className="w-16 h-16 text-green-600" />
                </div>
              ) : (
                <div className="bg-yellow-100 p-6 rounded-full">
                  <AlertCircle className="w-16 h-16 text-yellow-600" />
                </div>
              )}
            </div>
            <CardTitle>Quiz Completed!</CardTitle>
            <CardDescription>{quiz.title}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <div className="text-gray-900 mb-2">Your Score</div>
              <div className="text-gray-500 mb-4">{score}%</div>
              <Progress value={score} className="h-4" />
            </div>

            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="p-4 bg-gray-50 rounded-lg">
                <p className="text-gray-500">Total Questions</p>
                <p className="text-gray-900">{questions.length}</p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <p className="text-gray-500">Correct</p>
                <p className="text-green-600">{Math.round((score / 100) * questions.length)}</p>
              </div>
              <div className="p-4 bg-red-50 rounded-lg">
                <p className="text-gray-500">Incorrect</p>
                <p className="text-red-600">{questions.length - Math.round((score / 100) * questions.length)}</p>
              </div>
            </div>

            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {score >= 70 
                  ? 'Great job! You passed the quiz.'
                  : 'Keep practicing! Review the material and try again.'}
              </AlertDescription>
            </Alert>

            <div className="space-y-3">
              <h3 className="text-gray-900">Review Answers</h3>
              {questions.map((q, index) => (
                <div key={q.id} className="p-4 border rounded-lg">
                  <div className="flex items-start space-x-2 mb-2">
                    {answers[index] === q.correctAnswer ? (
                      <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    )}
                    <p className="text-gray-900">{index + 1}. {q.question}</p>
                  </div>
                  <div className="ml-7 space-y-1 text-gray-600">
                    <p>Your answer: <span className={answers[index] === q.correctAnswer ? 'text-green-600' : 'text-red-600'}>{q.options[answers[index]] || 'Not answered'}</span></p>
                    {answers[index] !== q.correctAnswer && (
                      <p>Correct answer: <span className="text-green-600">{q.options[q.correctAnswer]}</span></p>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <Button onClick={onExit} className="w-full">
              Return to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <Card className="mb-4">
          <CardContent className="py-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-gray-900">{quiz.title}</h2>
                <p className="text-gray-500">{quiz.class}</p>
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2 text-gray-600">
                  <Clock className="w-5 h-5" />
                  <span className={timeRemaining < 60 ? 'text-red-600' : ''}>{formatTime(timeRemaining)}</span>
                </div>
                <Button variant="outline" onClick={onExit}>
                  Exit
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Progress */}
        <Card className="mb-4">
          <CardContent className="py-4">
            <div className="space-y-2">
              <div className="flex justify-between text-gray-600">
                <span>Question {currentQuestionIndex + 1} of {questions.length}</span>
                <span>{Math.round(progress)}% Complete</span>
              </div>
              <Progress value={progress} />
            </div>
          </CardContent>
        </Card>

        {/* Question */}
        <Card className="mb-4">
          <CardHeader>
            <CardTitle>Question {currentQuestionIndex + 1}</CardTitle>
            <CardDescription className="mt-4 text-gray-900">{currentQuestion.question}</CardDescription>
          </CardHeader>
          <CardContent>
            <RadioGroup
              value={String(answers[currentQuestionIndex] ?? '')}
              onValueChange={(value) => handleAnswerChange(parseInt(value))}
            >
              <div className="space-y-3">
                {currentQuestion.options.map((option, index) => (
                  <div
                    key={index}
                    className={`flex items-center space-x-3 p-4 border rounded-lg cursor-pointer hover:bg-gray-50 ${
                      answers[currentQuestionIndex] === index ? 'border-indigo-600 bg-indigo-50' : ''
                    }`}
                  >
                    <RadioGroupItem value={String(index)} id={`option-${index}`} />
                    <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                      {String.fromCharCode(65 + index)}. {option}
                    </Label>
                  </div>
                ))}
              </div>
            </RadioGroup>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={() => setCurrentQuestionIndex(Math.max(0, currentQuestionIndex - 1))}
            disabled={currentQuestionIndex === 0}
          >
            Previous
          </Button>
          
          {currentQuestionIndex === questions.length - 1 ? (
            <Button onClick={handleSubmit}>
              Submit Quiz
            </Button>
          ) : (
            <Button
              onClick={() => setCurrentQuestionIndex(Math.min(questions.length - 1, currentQuestionIndex + 1))}
            >
              Next
            </Button>
          )}
        </div>

        {/* Question Navigator */}
        <Card className="mt-4">
          <CardContent className="py-4">
            <p className="text-gray-600 mb-3">Question Navigator</p>
            <div className="grid grid-cols-10 gap-2">
              {questions.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentQuestionIndex(index)}
                  className={`p-2 rounded text-center ${
                    index === currentQuestionIndex
                      ? 'bg-indigo-600 text-white'
                      : answers[index] !== undefined
                      ? 'bg-green-100 text-green-800'
                      : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  {index + 1}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
