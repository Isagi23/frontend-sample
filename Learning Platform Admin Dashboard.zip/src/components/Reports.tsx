import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { BarChart3, Download, TrendingUp, Users, BookOpen, FileQuestion } from 'lucide-react';
import { useState } from 'react';
import { Progress } from './ui/progress';

export function Reports() {
  const [reportType, setReportType] = useState('overview');

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Reports & Analytics</CardTitle>
              <CardDescription>View system-wide statistics and generate reports</CardDescription>
            </div>
            <div className="flex items-center space-x-2">
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Select report type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="overview">System Overview</SelectItem>
                  <SelectItem value="student">Student Performance</SelectItem>
                  <SelectItem value="teacher">Teacher Activity</SelectItem>
                  <SelectItem value="class">Class Statistics</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {reportType === 'overview' && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle>Active Users</CardTitle>
                <Users className="w-4 h-4 text-gray-500" />
              </CardHeader>
              <CardContent>
                <div className="text-gray-900">263</div>
                <p className="text-gray-500">Total active users</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                  <span className="text-green-600">+12% from last month</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle>Total Classes</CardTitle>
                <BookOpen className="w-4 h-4 text-gray-500" />
              </CardHeader>
              <CardContent>
                <div className="text-gray-900">32</div>
                <p className="text-gray-500">Active classes</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                  <span className="text-green-600">+5 new this month</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle>Assignments</CardTitle>
                <FileQuestion className="w-4 h-4 text-gray-500" />
              </CardHeader>
              <CardContent>
                <div className="text-gray-900">148</div>
                <p className="text-gray-500">Total assignments</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="w-4 h-4 text-green-600 mr-1" />
                  <span className="text-green-600">+23 this week</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle>Completion Rate</CardTitle>
                <BarChart3 className="w-4 h-4 text-gray-500" />
              </CardHeader>
              <CardContent>
                <div className="text-gray-900">87%</div>
                <p className="text-gray-500">Average completion</p>
                <Progress value={87} className="mt-2" />
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Class Performance Overview</CardTitle>
              <CardDescription>Average performance by class</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { name: 'Introduction to Computer Science', students: 25, avgGrade: 88, completion: 92 },
                  { name: 'Data Structures', students: 30, avgGrade: 85, completion: 88 },
                  { name: 'Web Development', students: 28, avgGrade: 91, completion: 95 },
                  { name: 'Database Systems', students: 22, avgGrade: 82, completion: 85 },
                  { name: 'Software Engineering', students: 26, avgGrade: 86, completion: 90 },
                ].map((classItem, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-gray-900">{classItem.name}</h4>
                      <span className="text-gray-500">{classItem.students} students</span>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-gray-500 mb-1">Average Grade</p>
                        <div className="flex items-center">
                          <Progress value={classItem.avgGrade} className="flex-1 mr-2" />
                          <span className="text-gray-900">{classItem.avgGrade}%</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-gray-500 mb-1">Completion Rate</p>
                        <div className="flex items-center">
                          <Progress value={classItem.completion} className="flex-1 mr-2" />
                          <span className="text-gray-900">{classItem.completion}%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Top Performing Students</CardTitle>
                <CardDescription>Highest average grades</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { name: 'Emma Johnson', id: '2021002', grade: 96 },
                    { name: 'Sarah Davis', id: '2021004', grade: 94 },
                    { name: 'Alex Smith', id: '2021001', grade: 92 },
                    { name: 'Michael Brown', id: '2021003', grade: 91 },
                    { name: 'James Wilson', id: '2021005', grade: 89 },
                  ].map((student, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="bg-indigo-100 text-indigo-600 w-8 h-8 rounded-full flex items-center justify-center">
                          {index + 1}
                        </div>
                        <div>
                          <p className="text-gray-900">{student.name}</p>
                          <p className="text-gray-500">{student.id}</p>
                        </div>
                      </div>
                      <div className="text-gray-900">{student.grade}%</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Latest system activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { action: 'New quiz created', teacher: 'Prof. Johnson', time: '2 hours ago' },
                    { action: 'Assignment submitted', student: 'Emma Johnson', time: '3 hours ago' },
                    { action: 'New class created', teacher: 'Dr. Smith', time: '5 hours ago' },
                    { action: 'Student enrolled', student: 'Michael Brown', time: '1 day ago' },
                    { action: 'Grades posted', teacher: 'Prof. Williams', time: '1 day ago' },
                  ].map((activity, index) => (
                    <div key={index} className="p-3 border rounded-lg">
                      <p className="text-gray-900">{activity.action}</p>
                      <div className="flex items-center justify-between mt-1">
                        <p className="text-gray-500">
                          {activity.teacher ? `by ${activity.teacher}` : activity.student}
                        </p>
                        <p className="text-gray-400">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}
