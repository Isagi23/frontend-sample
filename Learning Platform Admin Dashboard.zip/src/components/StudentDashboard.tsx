import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Badge } from './ui/badge';
import { LogOut, BookOpen, ClipboardList, FileQuestion, Clock, CheckCircle2, CreditCard, Sparkles } from 'lucide-react';
import { Progress } from './ui/progress';
import { QuizTaker } from './QuizTaker';
import { StudentGrades } from './StudentGrades';
import { PaymentManager } from './PaymentManager';
import { AIAssistant } from './AIAssistant';

interface StudentDashboardProps {
  user: any;
  onLogout: () => void;
}

export function StudentDashboard({ user, onLogout }: StudentDashboardProps) {
  const [selectedQuiz, setSelectedQuiz] = useState<any>(null);
  
  const [enrolledClasses] = useState([
    { id: '1', name: 'Introduction to Computer Science', teacher: 'Prof. Johnson', students: 25, color: 'bg-blue-500' },
    { id: '2', name: 'Data Structures', teacher: 'Dr. Smith', students: 30, color: 'bg-green-500' },
    { id: '3', name: 'Web Development', teacher: 'Prof. Williams', students: 28, color: 'bg-purple-500' },
  ]);

  const [activities] = useState([
    { id: '1', title: 'Assignment 1: Variables and Data Types', class: 'Introduction to Computer Science', dueDate: '2025-10-25', status: 'pending', points: 100 },
    { id: '2', title: 'Lab: Arrays and Linked Lists', class: 'Data Structures', dueDate: '2025-10-22', status: 'submitted', points: 50 },
    { id: '3', title: 'Project: Build a Portfolio Website', class: 'Web Development', dueDate: '2025-10-30', status: 'pending', points: 200 },
  ]);

  const [quizzes] = useState([
    { 
      id: '1', 
      title: 'Quiz 1: Python Basics', 
      class: 'Introduction to Computer Science', 
      dueDate: '2025-10-23', 
      status: 'available',
      duration: 30,
      questions: 10,
      points: 100
    },
    { 
      id: '2', 
      title: 'Quiz 2: Tree Traversal', 
      class: 'Data Structures', 
      dueDate: '2025-10-24', 
      status: 'completed',
      duration: 45,
      questions: 15,
      score: 85,
      points: 100
    },
  ]);

  if (selectedQuiz) {
    return <QuizTaker quiz={selectedQuiz} onExit={() => setSelectedQuiz(null)} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <BookOpen className="w-8 h-8 text-indigo-600" />
              <div>
                <h1 className="text-gray-900">Student Dashboard</h1>
                <p className="text-gray-500">Your classes and assignments</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-gray-900">{user.name}</p>
                <Badge variant="outline">Student</Badge>
              </div>
              <Avatar>
                <AvatarFallback>ST</AvatarFallback>
              </Avatar>
              <Button onClick={onLogout} variant="outline" size="sm">
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle>Enrolled Classes</CardTitle>
              <BookOpen className="w-4 h-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-gray-900">{enrolledClasses.length}</div>
              <p className="text-gray-500">Active courses</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle>Pending Work</CardTitle>
              <ClipboardList className="w-4 h-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-gray-900">{activities.filter(a => a.status === 'pending').length}</div>
              <p className="text-gray-500">Assignments due</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle>Quizzes</CardTitle>
              <FileQuestion className="w-4 h-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-gray-900">{quizzes.filter(q => q.status === 'available').length}</div>
              <p className="text-gray-500">Available to take</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle>Average Grade</CardTitle>
              <CheckCircle2 className="w-4 h-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-gray-900">85%</div>
              <p className="text-gray-500">Overall performance</p>
            </CardContent>
          </Card>
        </div>

        {/* Content Tabs */}
        <Tabs defaultValue="classes" className="space-y-6">
          <TabsList>
            <TabsTrigger value="classes">My Classes</TabsTrigger>
            <TabsTrigger value="activities">Activities</TabsTrigger>
            <TabsTrigger value="quizzes">Quizzes</TabsTrigger>
            <TabsTrigger value="grades">Grades</TabsTrigger>
            <TabsTrigger value="payments">
              <CreditCard className="w-4 h-4 mr-2" />
              Payments
            </TabsTrigger>
            <TabsTrigger value="ai-assistant">
              <Sparkles className="w-4 h-4 mr-2" />
              AI Assistant
            </TabsTrigger>
          </TabsList>

          <TabsContent value="classes">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {enrolledClasses.map((classItem) => (
                <Card key={classItem.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className={`${classItem.color} h-24 -mx-6 -mt-6 rounded-t-lg mb-4`}></div>
                    <CardTitle>{classItem.name}</CardTitle>
                    <CardDescription>{classItem.teacher}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-500">{classItem.students} students</span>
                      <Button variant="outline" size="sm">View Class</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="activities">
            <Card>
              <CardHeader>
                <CardTitle>Assignments</CardTitle>
                <CardDescription>Complete your assignments before the due date</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activities.map((activity) => (
                    <div key={activity.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className="text-gray-900">{activity.title}</h3>
                          {activity.status === 'submitted' ? (
                            <Badge variant="default">Submitted</Badge>
                          ) : (
                            <Badge variant="secondary">Pending</Badge>
                          )}
                        </div>
                        <p className="text-gray-500">{activity.class}</p>
                        <div className="flex items-center space-x-4 mt-2">
                          <span className="text-gray-500 flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            Due: {activity.dueDate}
                          </span>
                          <span className="text-gray-500">{activity.points} points</span>
                        </div>
                      </div>
                      <Button variant={activity.status === 'submitted' ? 'outline' : 'default'}>
                        {activity.status === 'submitted' ? 'View Submission' : 'Submit Work'}
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="quizzes">
            <Card>
              <CardHeader>
                <CardTitle>Quizzes</CardTitle>
                <CardDescription>Take your quizzes before the deadline</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {quizzes.map((quiz) => (
                    <div key={quiz.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className="text-gray-900">{quiz.title}</h3>
                          {quiz.status === 'completed' ? (
                            <Badge>Completed</Badge>
                          ) : (
                            <Badge variant="secondary">Available</Badge>
                          )}
                        </div>
                        <p className="text-gray-500">{quiz.class}</p>
                        <div className="flex items-center space-x-4 mt-2">
                          <span className="text-gray-500 flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            Due: {quiz.dueDate}
                          </span>
                          <span className="text-gray-500">{quiz.duration} min</span>
                          <span className="text-gray-500">{quiz.questions} questions</span>
                        </div>
                        {quiz.status === 'completed' && (
                          <div className="mt-2">
                            <Progress value={quiz.score} className="h-2" />
                            <p className="text-gray-500 mt-1">Score: {quiz.score}%</p>
                          </div>
                        )}
                      </div>
                      <Button 
                        variant={quiz.status === 'completed' ? 'outline' : 'default'}
                        onClick={() => quiz.status === 'available' && setSelectedQuiz(quiz)}
                      >
                        {quiz.status === 'completed' ? 'Review' : 'Start Quiz'}
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="grades">
            <StudentGrades />
          </TabsContent>

          <TabsContent value="payments">
            <PaymentManager />
          </TabsContent>

          <TabsContent value="ai-assistant">
            <AIAssistant />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}