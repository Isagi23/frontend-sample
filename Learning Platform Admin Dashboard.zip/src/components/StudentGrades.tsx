import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { TrendingUp, TrendingDown, Award, FileText } from 'lucide-react';
import { useState } from 'react';

export function StudentGrades() {
  const [selectedClass, setSelectedClass] = useState('all');

  const grades = [
    {
      id: '1',
      class: 'Introduction to Computer Science',
      assignments: [
        { name: 'Assignment 1: Variables', grade: 95, maxGrade: 100, submitted: '2025-10-18', feedback: 'Excellent work!' },
        { name: 'Quiz 1: Python Basics', grade: 88, maxGrade: 100, submitted: '2025-10-15', feedback: 'Good understanding of concepts.' },
        { name: 'Lab 1: Hello World', grade: 100, maxGrade: 100, submitted: '2025-10-12', feedback: 'Perfect!' },
      ],
      average: 94.3
    },
    {
      id: '2',
      class: 'Data Structures',
      assignments: [
        { name: 'Lab: Arrays and Linked Lists', grade: 90, maxGrade: 100, submitted: '2025-10-20', feedback: 'Well done. Minor improvements needed.' },
        { name: 'Quiz 2: Tree Traversal', grade: 85, maxGrade: 100, submitted: '2025-10-17', feedback: 'Review recursion concepts.' },
      ],
      average: 87.5
    },
    {
      id: '3',
      class: 'Web Development',
      assignments: [
        { name: 'Project: Portfolio Website', grade: 92, maxGrade: 100, submitted: '2025-10-19', feedback: 'Creative design. Good responsive layout.' },
      ],
      average: 92
    }
  ];

  const overallAverage = grades.reduce((sum, cls) => sum + cls.average, 0) / grades.length;

  const filteredGrades = selectedClass === 'all' 
    ? grades 
    : grades.filter(g => g.class === selectedClass);

  return (
    <div className="space-y-6">
      {/* Overall Performance */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle>Overall Average</CardTitle>
            <Award className="w-4 h-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-gray-900">{overallAverage.toFixed(1)}%</div>
            <Progress value={overallAverage} className="mt-2" />
            <div className="flex items-center mt-2 text-green-600">
              <TrendingUp className="w-4 h-4 mr-1" />
              <span>+3.2% from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle>Assignments Graded</CardTitle>
            <FileText className="w-4 h-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-gray-900">6</div>
            <p className="text-gray-500">Out of 8 total</p>
            <Progress value={75} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle>Highest Grade</CardTitle>
            <TrendingUp className="w-4 h-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-gray-900">100%</div>
            <p className="text-gray-500">Lab 1: Hello World</p>
            <Badge className="mt-2 bg-green-100 text-green-800">Perfect Score</Badge>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle>Lowest Grade</CardTitle>
            <TrendingDown className="w-4 h-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-gray-900">85%</div>
            <p className="text-gray-500">Quiz 2: Tree Traversal</p>
            <Badge className="mt-2 bg-orange-100 text-orange-800">Room for Improvement</Badge>
          </CardContent>
        </Card>
      </div>

      {/* Grades by Class */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Grades by Class</CardTitle>
              <CardDescription>View your grades and feedback</CardDescription>
            </div>
            <Select value={selectedClass} onValueChange={setSelectedClass}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="Filter by class" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                {grades.map(grade => (
                  <SelectItem key={grade.id} value={grade.class}>
                    {grade.class}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {filteredGrades.map((classGrades) => (
              <div key={classGrades.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-gray-900">{classGrades.class}</h3>
                    <p className="text-gray-500">Class Average: {classGrades.average.toFixed(1)}%</p>
                  </div>
                  <div className="text-right">
                    <div className="text-gray-900 mb-1">{classGrades.average.toFixed(1)}%</div>
                    <Progress value={classGrades.average} className="w-32" />
                  </div>
                </div>

                <div className="space-y-3">
                  {classGrades.assignments.map((assignment, index) => (
                    <div key={index} className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <h4 className="text-gray-900">{assignment.name}</h4>
                            <div className="flex items-center space-x-2">
                              <span className="text-gray-900">
                                {assignment.grade}/{assignment.maxGrade}
                              </span>
                              <Badge 
                                variant={assignment.grade >= 90 ? 'default' : assignment.grade >= 70 ? 'secondary' : 'destructive'}
                              >
                                {((assignment.grade / assignment.maxGrade) * 100).toFixed(0)}%
                              </Badge>
                            </div>
                          </div>
                          <p className="text-gray-500 mt-1">Submitted: {assignment.submitted}</p>
                        </div>
                      </div>
                      {assignment.feedback && (
                        <div className="mt-3 p-3 bg-white rounded border-l-4 border-indigo-600">
                          <p className="text-gray-600">
                            <span className="text-gray-900">Feedback:</span> {assignment.feedback}
                          </p>
                        </div>
                      )}
                      <div className="mt-2">
                        <Progress value={(assignment.grade / assignment.maxGrade) * 100} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Grade Distribution */}
      <Card>
        <CardHeader>
          <CardTitle>Grade Distribution</CardTitle>
          <CardDescription>Your performance across all assignments</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">A (90-100%)</span>
              <div className="flex items-center space-x-3 flex-1 ml-4">
                <Progress value={66.7} className="flex-1" />
                <span className="text-gray-900 w-12 text-right">4</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">B (80-89%)</span>
              <div className="flex items-center space-x-3 flex-1 ml-4">
                <Progress value={33.3} className="flex-1" />
                <span className="text-gray-900 w-12 text-right">2</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">C (70-79%)</span>
              <div className="flex items-center space-x-3 flex-1 ml-4">
                <Progress value={0} className="flex-1" />
                <span className="text-gray-900 w-12 text-right">0</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Below 70%</span>
              <div className="flex items-center space-x-3 flex-1 ml-4">
                <Progress value={0} className="flex-1" />
                <span className="text-gray-900 w-12 text-right">0</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
