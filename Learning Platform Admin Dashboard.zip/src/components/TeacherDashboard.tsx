import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Badge } from './ui/badge';
import { LogOut, BookOpen, ClipboardList, FileQuestion, Users } from 'lucide-react';
import { ClassManager } from './ClassManager';
import { ActivityUploader } from './ActivityUploader';
import { QuizBuilder } from './QuizBuilder';
import { GradeManagement } from './GradeManagement';

interface TeacherDashboardProps {
  user: any;
  onLogout: () => void;
}

export function TeacherDashboard({ user, onLogout }: TeacherDashboardProps) {
  const [stats] = useState({
    myClasses: 5,
    totalStudents: 87,
    activeActivities: 12,
    activeQuizzes: 4
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <BookOpen className="w-8 h-8 text-indigo-600" />
              <div>
                <h1 className="text-gray-900">Teacher Dashboard</h1>
                <p className="text-gray-500">Manage your classes and activities</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-gray-900">{user.name}</p>
                <Badge>Teacher</Badge>
              </div>
              <Avatar>
                <AvatarFallback>TC</AvatarFallback>
              </Avatar>
              <Button onClick={onLogout} variant="outline" size="sm">
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle>My Classes</CardTitle>
              <BookOpen className="w-4 h-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-gray-900">{stats.myClasses}</div>
              <p className="text-gray-500">Active classes</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle>Total Students</CardTitle>
              <Users className="w-4 h-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-gray-900">{stats.totalStudents}</div>
              <p className="text-gray-500">Across all classes</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle>Activities</CardTitle>
              <ClipboardList className="w-4 h-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-gray-900">{stats.activeActivities}</div>
              <p className="text-gray-500">Active assignments</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle>Quizzes</CardTitle>
              <FileQuestion className="w-4 h-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-gray-900">{stats.activeQuizzes}</div>
              <p className="text-gray-500">Active quizzes</p>
            </CardContent>
          </Card>
        </div>

        {/* Management Tabs */}
        <Tabs defaultValue="classes" className="space-y-6">
          <TabsList>
            <TabsTrigger value="classes">My Classes</TabsTrigger>
            <TabsTrigger value="activities">Activities</TabsTrigger>
            <TabsTrigger value="quizzes">Quizzes</TabsTrigger>
            <TabsTrigger value="grading">Grading</TabsTrigger>
          </TabsList>

          <TabsContent value="classes">
            <ClassManager isAdmin={false} />
          </TabsContent>

          <TabsContent value="activities">
            <ActivityUploader />
          </TabsContent>

          <TabsContent value="quizzes">
            <QuizBuilder />
          </TabsContent>

          <TabsContent value="grading">
            <GradeManagement />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
